# ThreadCloneApp
It is a clone app. I have created this app with the help of jetpack compose language. I have used many dependencies in it like material3, navigation,ktx, firebase,constraint-layout, viewmodel, mvvm, livedata, coil, swiperefresh and so on. And I have built this only for Android Platform.
